<div class="toggle-sidebar" wire:click="sidebar"><i class="status_toggle middle sidebar-toggle" data-feather="grid"> </i>
</div>
