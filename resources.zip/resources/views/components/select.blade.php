<div  {{ $attributes }} >
    <h2>hoass</h2>
    {{ $items }}
    {{ $title }}
</div>
