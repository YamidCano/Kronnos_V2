<footer class="footer footer-fix">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 footer-copyright text-center">
                <p class="mb-0">Copyright {{ date('Y') }} © Kronnos</p>
            </div>
        </div>
    </div>
</footer>
