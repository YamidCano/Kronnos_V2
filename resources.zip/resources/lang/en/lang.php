<?php
	return  [
		'In Use' => 'In Use',
        'Settings' => 'Settings',
        'Create Role' => 'Create Role',
        'Close' => 'Close',
        'Role' => 'Role',
        'Permission' => 'Permission',
        'Name' => 'Name',
        'Edit Role' => 'Editar Role',
        'Save' => 'Save',
        'Are you sure to delete?' => 'Are you sure to delete?',
        'Logout' => 'Logout',
        'Profile' => 'Profile',
        '' => '',
        '' => '',
        '' => '',
        '' => '',
	]
?>
