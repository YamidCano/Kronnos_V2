<?php
	//Spanish
	return  [
		'In Use' => 'En Uso',
        'Settings' => 'Ajustes',
        'Create Role' => 'Crear Rol',
        'Close' => 'Cerrar',
        'Role' => 'Rol',
        'Permission' => 'Permisos',
        'Name' => 'Nombre',
        'Edit Role' => 'Editar Rol',
        'Save' => 'Guardar',
        'Update' => 'Actualizar',
        'Are you sure to delete?' => '¿Estas seguro de eliminar?',
        'Logout' => 'Salir',
        'Profile' => 'Perfil',
        '' => '',
        '' => '',
        '' => '',
        '' => '',
    ]
?>
