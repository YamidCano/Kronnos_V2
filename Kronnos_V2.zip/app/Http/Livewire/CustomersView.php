<?php

namespace App\Http\Livewire;

use Livewire\Component;

class CustomersView extends Component
{
    public function render()
    {
        return view('livewire.customers-view');
    }
}
