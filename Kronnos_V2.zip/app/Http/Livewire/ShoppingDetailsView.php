<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ShoppingDetailsView extends Component
{
    public function render()
    {
        return view('livewire.shopping-details-view');
    }
}
