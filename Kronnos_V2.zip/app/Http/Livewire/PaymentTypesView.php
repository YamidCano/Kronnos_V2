<?php

namespace App\Http\Livewire;

use Livewire\Component;

class PaymentTypesView extends Component
{
    public function render()
    {
        return view('livewire.payment-types-view');
    }
}
