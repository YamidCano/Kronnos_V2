<div class="sidebar-wrapper">
    <div class="sidebar-top"><a href="#" class="slidepanel-toggle"><i
                class="icon icon-left-arrow-circular"></i></a></div>
    <ul class="sidebar-nav">
        <li> <a href="index.html">HOME</a> </li>
        <li> <a href="gallery.html">GALLERY</a> </li>
        <li> <a href="blog.html">BLOG</a> </li>
        <li> <a href="category-fixed-sidebar.html">SHOP</a> </li>
        <li> <a href="faq.html">FAQ</a> </li>
        <li> <a href="contact.html">CONTACT</a> </li>
    </ul>
    <div class="sidebar-bot">
        <div class="share-button toTop">
            <span class="toggle"></span>
            <ul class="social-list">
                <li>
                    <a href="#" class="icon icon-google google"></a>
                </li>
                <li>
                    <a href="#" class="icon icon-fancy fancy"></a>
                </li>
                <li>
                    <a href="#" class="icon icon-pinterest pinterest"></a>
                </li>
                <li>
                    <a href="#" class="icon icon-twitter-logo twitter"></a>
                </li>
                <li>
                    <a href="#" class="icon icon-facebook-logo facebook"></a>
                </li>
            </ul>
        </div>
    </div>
</div>
