 <!-- Vendor -->
 <link href="{{ asset('seiko') }}/js/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
 <link href="{{ asset('seiko') }}/js/vendor/slick/slick.css" rel="stylesheet">
 <link href="{{ asset('seiko') }}/js/vendor/swiper/swiper.min.css" rel="stylesheet">
 <link href="{{ asset('seiko') }}/js/vendor/magnificpopup/dist/magnific-popup.css" rel="stylesheet">
 <link href="{{ asset('seiko') }}/js/vendor/nouislider/nouislider.css" rel="stylesheet">
 <link href="{{ asset('seiko') }}/js/vendor/darktooltip/dist/darktooltip.css" rel="stylesheet">
 <link href="{{ asset('seiko') }}/css/animate.css" rel="stylesheet">

 <!-- Custom -->
 <link href="{{ asset('seiko') }}/css/style.css" rel="stylesheet">
 <link href="{{ asset('seiko') }}/css/megamenu.css" rel="stylesheet">

 <!-- Color Schemes -->
 <!-- your style-color.css here  -->
 <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/font-awesome.css') }}">
 <!-- ico-font-->
 <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/vendors/icofont.css') }}">


 <!-- Icon Font -->
 <link href="{{ asset('seiko') }}/fonts/icomoon-reg/style.css" rel="stylesheet">

 <!-- Google Font -->
 <link
 href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i"
 rel="stylesheet">
