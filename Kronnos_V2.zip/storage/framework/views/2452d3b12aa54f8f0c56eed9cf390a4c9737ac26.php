<div <?php if(auth()->user()->sidebar == 1): ?> class="sidebar-wrapper close_icon"
    <?php else: ?> class="sidebar-wrapper" <?php endif; ?>>
    <div>
        <div class="logo-wrapper">
            <img class="img-fluid for-light" src="../assets/images/logo/logo.png" alt="">
            <img class="img-fluid for-dark" src="../assets/images/logo/logo.png" alt="">
            <div class="back-btn"><i class="fa fa-angle-left"></i></div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.sidebar')->html();
} elseif ($_instance->childHasBeenRendered('7yedsuV')) {
    $componentId = $_instance->getRenderedChildComponentId('7yedsuV');
    $componentTag = $_instance->getRenderedChildComponentTagName('7yedsuV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7yedsuV');
} else {
    $response = \Livewire\Livewire::mount('components.sidebar');
    $html = $response->html();
    $_instance->logRenderedChild('7yedsuV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="logo-icon-wrapper"><a href="<?php echo e(url('home')); ?>"><img class="img-fluid"
                    src="../assets/images/logo/logo-icon.png" alt=""></a></div>
        <nav class="sidebar-main">
            <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
            <div id="sidebar-menu">
                <ul class="sidebar-links" id="simple-bar">
                    <li class="back-btn"><a href="<?php echo e(url('home')); ?>"><img class="img-fluid"
                                src="../assets/images/logo/logo-icon.png" alt=""></a>
                        <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2"
                                aria-hidden="true"></i></div>
                    </li>
                    <li class="sidebar-main-title">
                        <div class="text-center">
                            <img class="img-70 rounded-circle" alt=""
                                src="https://ui-avatars.com/api/?name=<?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->last_name); ?>.'&color=FFFFFF&background=e74c3c">
                            <div>
                                <h5 class="mb-1 text-danger"><?php echo e(Auth::user()->name); ?></h5>
                                <p><?php echo e(Auth::user()->last_name); ?></p>
                            </div>
                        </div>
                    </li>
                    <li class="sidebar-list">
                        
                        <a class="sidebar-link sidebar-title <?php echo e(Route::currentRouteName() == 'home' ? 'active' : ''); ?>"
                            href="<?php echo e(url('home')); ?>">
                            <i data-feather="home"></i><span class="lan-6">Dashboard </span></a>
                    </li>
                    <?php if(canView('Usuario - Tabla') or canView('Role y Permisos - Tabla')): ?>
                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title <?php if(Route::currentRouteName() == 'usuarios' or Route::currentRouteName() == 'rolesPermisos'): ?> active <?php endif; ?>"
                                href="#"><i data-feather="users"></i><span class="lan-6">Usuarios</span>
                                <div class="according-menu"><i
                                        class="<?php if(Route::currentRouteName() == 'usuarios' or Route::currentRouteName() == 'rolesPermisos'): ?> fa fa-angle-down <?php else: ?>  fa fa-angle-right <?php endif; ?>"></i>
                                </div>
                            </a>
                            <ul class="sidebar-submenu"
                                style="<?php if(Route::currentRouteName() == 'usuarios' or Route::currentRouteName() == 'rolesPermisos'): ?> display: block; <?php else: ?>  display: none; <?php endif; ?>">
                                <?php if(canView('Usuario - Tabla')): ?>
                                    <li>
                                        <a href="<?php echo e(url('usuarios')); ?>"
                                            class="<?php echo e(Route::currentRouteName() == 'usuarios' ? 'active' : ''); ?>">
                                            Listado de Usuarios
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(canView('Role y Permisos - Tabla')): ?>
                                    <li>
                                        <a href="<?php echo e(url('rolesPermisos')); ?>"
                                            class="<?php echo e(Route::currentRouteName() == 'rolesPermisos' ? 'active' : ''); ?>">
                                            Roles y Permisos
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if(canView('Proveedor - Tabla')): ?>
                        <li class="sidebar-list">
                            
                            <a class="sidebar-link sidebar-title <?php echo e(Route::currentRouteName() == 'proveedores' ? 'active' : ''); ?>"
                                href="<?php echo e(url('proveedores')); ?>">
                                <i data-feather="truck"></i><span class="lan-6">Proveedores</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if(canView('Producto - Tabla') or canView('Brands - Tabla') or canView('Categoria-Producto - Tabla')): ?>
                        <li class="sidebar-list"><a
                                class="sidebar-link sidebar-title <?php if(Route::currentRouteName() == 'ProductoCategoria' or Route::currentRouteName() == 'marcas' or Route::currentRouteName() == 'productos'): ?> active <?php endif; ?>"
                                href="#"><i data-feather="package"></i><span class="lan-6">Productos</span>
                                <div class="according-menu"><i
                                        class="<?php if(Route::currentRouteName() == 'ProductoCategoria' or Route::currentRouteName() == 'marcas' or Route::currentRouteName() == 'productos'): ?> fa fa-angle-down <?php else: ?>  fa fa-angle-right <?php endif; ?>"></i>
                                </div>
                            </a>
                            <ul class="sidebar-submenu"
                                style=" <?php if(Route::currentRouteName() == 'ProductoCategoria' or Route::currentRouteName() == 'marcas' or Route::currentRouteName() == 'productos'): ?> display: block; <?php else: ?>  display: none; <?php endif; ?>">
                                <?php if(canView('Producto - Tabla')): ?>
                                    <li>
                                        <a href="<?php echo e(url('productos')); ?>"
                                            class="<?php echo e(Route::currentRouteName() == 'productos' ? 'active' : ''); ?>">
                                            Listado Productos
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(canView('Categoria-Producto - Tabla')): ?>
                                    <li>
                                        <a href="<?php echo e(url('ProductoCategoria')); ?>"
                                            class="<?php echo e(Route::currentRouteName() == 'ProductoCategoria' ? 'active' : ''); ?>">
                                            Categoria de Producto
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(canView('Brands - Tabla')): ?>
                                    <li>
                                        <a href="<?php echo e(url('marcas')); ?>"
                                            class="<?php echo e(Route::currentRouteName() == 'marcas' ? 'active' : ''); ?>">
                                            Marcas
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if(canView('Inventorie - Tabla')): ?>
                        <li class="sidebar-list">
                            
                            <a class="sidebar-link sidebar-title <?php echo e(Route::currentRouteName() == 'ajusteInventario' ? 'active' : ''); ?>"
                                href="<?php echo e(url('ajusteInventario')); ?>">
                                <i data-feather="layers"></i><span class="lan-6">Ajuste de Stock </span></a>
                        </li>
                    <?php endif; ?>
                    <?php if(canView('Shopping - Tabla') or canView('Taxes - Tabla')): ?>
                        <li class="sidebar-list"><a
                                class="sidebar-link sidebar-title <?php if(Route::currentRouteName() == 'compras' or Route::currentRouteName() == 'impuestos'): ?> active <?php endif; ?>"
                                href="#"><i data-feather="gift"></i><span class="lan-6">Compras</span>
                                <div class="according-menu"><i
                                        class="<?php if(Route::currentRouteName() == 'compras' or Route::currentRouteName() == 'impuestos'): ?> fa fa-angle-down <?php else: ?>  fa fa-angle-right <?php endif; ?>"></i>
                                </div>
                            </a>
                            <ul class="sidebar-submenu"
                                style=" <?php if(Route::currentRouteName() == 'compras' or Route::currentRouteName() == 'impuestos'): ?> display: block; <?php else: ?>  display: none; <?php endif; ?>">
                                <?php if(canView('Shopping - Tabla')): ?>
                                    <li>
                                        <a href="<?php echo e(url('compras')); ?>"
                                            class="<?php echo e(Route::currentRouteName() == 'compras' ? 'active' : ''); ?>">
                                            Compras
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(canView('Taxes - Tabla')): ?>
                                <li>
                                    <a href="<?php echo e(url('impuestos')); ?>"
                                        class="<?php echo e(Route::currentRouteName() == 'impuestos' ? 'active' : ''); ?>">
                                        Impuestos
                                    </a>
                                </li>
                            <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
        </nav>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Kronnos_V2\resources\views/layouts/cuba/sidebar.blade.php ENDPATH**/ ?>