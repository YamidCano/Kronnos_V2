<div>
    <div class="container-fluid">
        <div class="page-title">
            <div class="row">
                <div class="col-6">
                    <h3>Ajuste de Stock</h3>
                </div>
                <div class="col-6">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item">Ajuste de Stock</li>
                        
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-5">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Proveedor - Crear')): ?>
                                    <div class="mb-3">
                                        <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal"
                                            data-bs-target="#Store">
                                            Agregar Nuevo Ajuste de Stock
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-sm-6 col-md-5">
                                <div class="mb-3">
                                    <div class="input-group mb-3">
                                        <span class="input-group-text">
                                            <i class="icofont icofont-search"> </i>
                                        </span>
                                        <input class="form-control" type="search" wire:model="search"
                                            placeholder="Buscar" aria-label="Search">
                                        <?php if($search != null): ?>
                                            <span class="input-group-text" style="cursor:pointer;" wire:click="clean">
                                                <i class="icofont icofont-close-circled"> </i>
                                            </span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-6 col-md-2">
                                <div class="mb-3">
                                    <select class="form-select digits select2" id="perPage" wire:model="perPage">
                                        <option value="25">25</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                        <option value="250">250</option>
                                        <option value="500">500</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover card-table table-vcenter text-nowrap">
                                <thead>
                                    <tr>
                                        <th>Producto</th>
                                        <th>Usuario</th>
                                        <th>Cantidad</th>
                                        <th>Tipo de ajuste</th>
                                        <th>Nota</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($item->producto->name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->usuario->name); ?>

                                            </td>
                                            <td>
                                                <?php if($item->type == 0): ?>
                                                    <div class="text-success">
                                                        + <?php echo e($item->quantity); ?>

                                                    </div>
                                                <?php else: ?>
                                                    <div class="text-danger">
                                                        - <?php echo e($item->quantity); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($item->type == 0): ?>
                                                    <div class="text-success">
                                                        Agregar
                                                    </div>
                                                <?php else: ?>
                                                    <div class="text-danger">
                                                        Sustraer
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($item->comments); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <br>
                            <?php echo e($inventories->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div wire:ignore.self class="modal fade" id="Store" data-bs-backdrop="static" data-bs-keyboard="false"
        aria-labelledby="staticBackdropLabel" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">
                        Nuevo Ajuste de Stock
                    </h5>
                    <button type="button" class="btn-close" wire:click="close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="row row-sm">
                            <div>
                                <label for="buscar" class="mb-1">
                                    Seleccione un producto *
                                    
                                </label>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="icofont icofont-search"> </i>
                                        </span>
                                        <input wire:model="buscar" wire:keydown.enter="asignarPrimero()" type="text"
                                            class="form-control" id="buscar" autocomplete="off">
                                        <?php if($buscar != null): ?>
                                            <span class="input-group-text" style="cursor:pointer;" wire:click="close">
                                                <i class="icofont icofont-close-circled"> </i>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if(count($product) > 0): ?>
                                        <?php if(!$picked): ?>
                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="form-control" style="cursor: pointer"
                                                    wire:click="asignarProduct('<?php echo e($item->id); ?>')">
                                                    <?php echo e($item->name); ?>

                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if(!empty($buscar)): ?>
                                            <span class="form-control text-danger">
                                                No se han encontrado resultados
                                            </span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                                <?php $__errorArgs = ['buscar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['idproduct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(empty($buscar)): ?>
                                    <small class="form-text text-muted">
                                        <div>
                                            Comience digitar para que el resultado aparezca
                                        </div>
                                    </small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <br>
                        <?php if($idproduct != null): ?>
                            <div class="row row-sm">
                                <div class="col-lg">
                                    <label for="Name">Stock Actual</label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="icofont icofont-cubes"> </i>
                                        </span>
                                        <input type="number" placeholder="Stock Actual" disabled
                                            class="form-control <?php $__errorArgs = ['stockproducto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            wire:model="stockproducto" />
                                    </div>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger error"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg mg-t-10 mg-lg-t-0">
                                    <label for="Name">Stock *</label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="icofont icofont-cubes"> </i>
                                        </span>
                                        <input type="number" placeholder="Stock *"
                                            class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            wire:model="quantity" />
                                    </div>
                                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger error"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg mg-t-10 mg-lg-t-0">
                                    <label for="Name"><?php echo e(__('Tipo de ajuste')); ?> *</label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="icofont icofont-maximize"> </i>
                                        </span>
                                        <select wire:model="type"
                                            class="form-control <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="0">Agregar</option>
                                            <option value="1">Sustraer</option>
                                        </select>
                                    </div>

                                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger error"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                            <br>
                            <div class="row row-sm">
                                <div class="col-lg mg-t-10 mg-lg-t-0">
                                    <label for="Name">Nota</label>
                                    <textarea wire:model="comments" rows="3" cols="20" class="form-control <?php $__errorArgs = ['comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="<?php echo e(__('Nota')); ?>"></textarea>
                                    <?php $__errorArgs = ['comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger error"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" wire:click="close"
                        data-bs-dismiss="modal">Cerrar</button>
                    <?php if($idproduct != null): ?>
                        <button type="button" class="btn btn-primary" wire:loading.attr="disabled"
                            wire:target="updatestock" wire:click="updatestock">Crear</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>



</div>
<?php /**PATH C:\xampp\htdocs\Kronnos_V2\resources\views/livewire/inventories-view.blade.php ENDPATH**/ ?>