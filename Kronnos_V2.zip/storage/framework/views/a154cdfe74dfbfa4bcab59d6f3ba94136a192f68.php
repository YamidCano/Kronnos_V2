<div class="toggle-sidebar" wire:click="sidebar"><i class="status_toggle middle sidebar-toggle" data-feather="grid"> </i>
</div>
<?php /**PATH C:\xampp\htdocs\Kronnos_V2\resources\views/livewire/components/sidebar.blade.php ENDPATH**/ ?>