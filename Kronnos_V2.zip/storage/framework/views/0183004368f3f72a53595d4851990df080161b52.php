<div>
    <div class="container-fluid">
        <div class="page-title">
            <div class="row">
                <div class="col-6">
                    <h3>Crear Compra</h3>
                </div>
                <div class="col-6">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('compras')); ?>">Compras</a></li>
                        <li class="breadcrumb-item">Crear Compra</li>
                        
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div>
                                <a type="button" class="btn btn-primary float-end" href="<?php echo e(url('compras')); ?>">
                                    Volver
                                </a>
                            </div>
                        </div>
                        <?php if($selectProvider == null): ?>
                            <div class="row ">
                                <div class="col">
                                    <label for="Name">Selecione Proveedor *</label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="icofont icofont-fast-delivery"> </i>
                                        </span>
                                        <select class="form-control" wire:model="selectProvider">
                                            <option value="">
                                                Selecione Proveedor *
                                            </option>
                                            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['selectProvider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-6">
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="row">
                                <div class="col-6 mt-4">
                                    <div class="m-2">
                                        <div class="h6 mt-4">Nombre del Proveedor:
                                            <strong><?php echo e($providerName); ?></strong>
                                        </div>
                                        <button type="button" wire:click="clean2"
                                            class="btn btn-outline-secundary btn-icon float-end">
                                            <i class="icofont icofont-ui-delete text-danger" style="font-size: 20px;">
                                            </i>
                                        </button>
                                        <div class="h6">Rut: <strong><?php echo e($providerRut); ?></strong></div>
                                        <div class="h6">Telefono: <strong><?php echo e($providerPhone); ?></strong>
                                        </div>
                                        <div class="h6">Email: <strong><?php echo e($providerEmail); ?></strong></div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="col mt-4">
                                        <label for="Name">Numero Factura *</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text">
                                                <i class="icofont icofont-numbered"> </i>
                                            </span>
                                            <input class="form-control" type="text" wire:model="invoiceNumber"
                                                placeholder="Numero Factura *">
                                            <?php if($invoiceNumber != null): ?>
                                                <span class="input-group-text" style="cursor:pointer;"
                                                    wire:click="clean1">
                                                    <i class="icofont icofont-close-circled"> </i>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <?php $__errorArgs = ['invoiceNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col">
                                        <label for="Name">Selecione una fecha *</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-text">
                                                <i class="icofont icofont-calendar"> </i>
                                            </span>
                                            <input class="form-control" type="date" wire:model="date"
                                                placeholder="Numero Factura *">
                                            <?php if($date != null): ?>
                                                <span class="input-group-text" style="cursor:pointer;"
                                                    wire:click="clean3">
                                                    <i class="icofont icofont-close-circled"> </i>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>


                        <br>
                        <div class="row ">
                            <div class="col">
                                <div>
                                    <label for="buscar" class="mb-1">
                                        Seleccione un producto *
                                        
                                    </label>
                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-text">
                                                <i class="icofont icofont-search"> </i>
                                            </span>
                                            <input wire:model="buscar" wire:keydown.enter="asignarPrimero()" type="text"
                                                class="form-control" id="buscar" autocomplete="off">
                                            <?php if($buscar != null): ?>
                                                <span class="input-group-text" style="cursor:pointer;"
                                                    wire:click="close">
                                                    <i class="icofont icofont-close-circled"> </i>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <?php if(count($product) > 0): ?>
                                            <?php if(!$picked): ?>
                                                <div style="position: absolute;z-index: 5;width: 93%;"
                                                    class="shadow rounded">
                                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="form-control" style="cursor: pointer"
                                                            wire:click="asignarProduct('<?php echo e($item->id); ?>')">
                                                            <?php echo e($item->name); ?>

                                                        </span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if(!empty($buscar)): ?>
                                                <span class="form-control text-danger">
                                                    No se han encontrado resultados
                                                </span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php $__errorArgs = ['buscar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php $__errorArgs = ['idproduct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger error"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php if(empty($buscar)): ?>
                                        <small class="form-text text-muted">
                                            <div>
                                                Comience digitar para que el resultado aparezca
                                            </div>
                                        </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="order-history table-responsive wishlist">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Prdouct</th>
                                            <th>Prdouct Name</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Action</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <tr>
                                            <td>
                                                <div class="product-name"><a href="#">Long Top</a></div>
                                            </td>
                                            <td>
                                                <div class="product-name"><a href="#">Long Top</a></div>
                                            </td>
                                            <td>$21</td>
                                            <td>
                                                <fieldset class="qty-box">
                                                    <div class="input-group bootstrap-touchspin">
                                                        <button
                                                            class="btn btn-primary btn-square bootstrap-touchspin-down"
                                                            type="button">
                                                            <i class="fa fa-minus"></i>
                                                        </button>
                                                        <span class="input-group-text bootstrap-touchspin-prefix"
                                                            style="display: none;"></span>
                                                        <input class="touchspin text-center form-control" type="text"
                                                            value="5" style="display: block;">
                                                        <span class="input-group-text bootstrap-touchspin-postfix"
                                                            style="display: none;"></span>
                                                        <button
                                                            class="btn btn-primary btn-square bootstrap-touchspin-up"
                                                            type="button">
                                                            <i class="fa fa-plus"></i>
                                                        </button>
                                                    </div>
                                                </fieldset>
                                            </td>
                                            <td>
                                                <button type="button" wire:click="clean2"
                                                    class="btn btn-outline-secundary btn-icon float-end">
                                                    <i class="icofont icofont-ui-delete text-danger"
                                                        style="font-size: 20px;">
                                                    </i>
                                                </button>
                                            </td>
                                            <td>$12456</td>
                                        </tr>
                                        <tr>
                                            <td colspan="4">
                                                <div class="input-group">
                                                    <input class="form-control me-2" type="text"
                                                        placeholder="Enter coupan code"><a class="btn btn-primary"
                                                        href="#">Apply</a>
                                                </div>
                                            </td>
                                            <td class="total-amount">
                                                <h6 class="m-0 text-end">
                                                    <span class="f-w-600">Total Price
                                                        :</span>
                                                </h6>
                                            </td>
                                            <td><span>$6935.00 </span></td>
                                        </tr>
                                        <tr>
                                            <td class="text-end" colspan="6">
                                                <button type="button" class="btn btn-primary"
                                                    wire:loading.attr="disabled" wire:target="save, photo"
                                                    wire:click="save">Crear</button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\Kronnos_V2\resources\views/livewire/shopping-create-view.blade.php ENDPATH**/ ?>