<div class="mode" wire:click="theme">
    <?php if(auth()->user()->theme == 1): ?>
        <i class="fa fa-lightbulb-o"></i>
    <?php else: ?>
        <i class="fa fa-moon-o"></i>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\Kronnos_V2\resources\views/livewire/components/header.blade.php ENDPATH**/ ?>