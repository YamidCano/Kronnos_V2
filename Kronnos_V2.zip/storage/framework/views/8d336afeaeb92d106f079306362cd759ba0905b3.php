<div>
    <br>
    <br><br><br>
    hola
</div>
<?php /**PATH C:\xampp\htdocs\Kronnos_V2\resources\views/livewire/prueba-view.blade.php ENDPATH**/ ?>