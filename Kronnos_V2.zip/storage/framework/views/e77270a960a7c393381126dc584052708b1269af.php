<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    

    <?php echo $__env->make('layouts.cuba.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo \Livewire\Livewire::styles(); ?>


    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <style>
        textarea:focus,
        select:focus,
        input:focus,
        input[type]:focus {
            /* border: none; */
            border: 1px solid #ced4da;
            box-shadow: 0 2px 2px rgba(229, 37, 23, 0.075)inset, 0 0 8px #e74d3c00;
            outline: 0 none;
        }

        .form-select:focus {
            border-bottom: 3px solid #e74d3c00;
            outline: 0;
            /* border: none; */
            -webkit-box-shadow: 0 0 0 .25rem rgba(13, 110, 253, 0.25);
            box-shadow: 0 2px 2px rgba(229, 37, 23, 0.075)inset, 0 0 8px #e74d3c00;
        }
    </style>

</head>

<body onload="startTime()" <?php if(auth()->user()->theme == 1): ?> class="dark-only" <?php endif; ?>>
    <div class="loader-wrapper">
        <div class="loader-index"><span></span></div>
        <svg>
            <defs></defs>
            <filter id="goo">
                <fegaussianblur in="SourceGraphic" stddeviation="11" result="blur"></fegaussianblur>
                <fecolormatrix in="blur" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9" result="goo">
                </fecolormatrix>
            </filter>
        </svg>
    </div>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <!-- Page Header Start-->
        <?php echo $__env->make('layouts.cuba.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Page Header Ends                              -->
        <!-- Page Body Start-->
        <div class="page-body-wrapper">
            <!-- Page Sidebar Start-->
            <?php echo $__env->make('layouts.cuba.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Page Sidebar Ends-->
            <div class="page-body mb-5">
                <?php if (! empty(trim($__env->yieldContent('content')))): ?>
                    <main>
                        <?php echo $__env->yieldContent('content'); ?>
                    </main>
                <?php else: ?>
                    <?php echo e($slot); ?>

                <?php endif; ?>
                <!-- Container-fluid Ends-->
            </div>
            <!-- footer start-->
            <?php echo $__env->make('layouts.cuba.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <?php echo \Livewire\Livewire::scripts(); ?>


    

    <?php echo $__env->make('layouts.cuba.plugins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('js'); ?>



    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>

    <script>
        Livewire.on('alert', function(message) {
            Swal.fire(
                '¡Buen trabajo!',
                message,
                'success'
            )
        });

        Livewire.on('alertError', function(message) {
            Swal.fire(
                '¡Algo no va bien!',
                message,
                'error'
            )
        });

        window.livewire.on('Store', () => {
            $('#Store').modal('hide');
        });

        window.livewire.on('update', () => {
            $('#update').modal('hide');
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Kronnos_V2\resources\views/layouts/app.blade.php ENDPATH**/ ?>