<div wire:ignore x-data="{}" x-init="() => {
    $('.select2').select2();
    $('.select2').on('change', function(e) {

        let elementName = $(this).attr('id');
        window.livewire.find('<?php echo e($_instance->id); ?>').set(elementName, e.target.value);
        Livewire.hook('message.processed', (m, component) => {
            $('.select2').select2();
        })

    })
}">
    <select class="select2 form-control" <?php echo e($attributes); ?>>
        <option value=""> <?php echo e($title); ?> -- <?php echo e($dataid); ?></option>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e(4 == $option->id ? 'selected' : null); ?> value="<?php echo e($option->id); ?>">
                <?php echo e($option->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH C:\xampp\htdocs\Kronnos_V2\resources\views/components/select-component.blade.php ENDPATH**/ ?>