<header class="page-header fullboxed variant-9 sticky always">
    <!-- Header Top Row -->
    <div class="header-top-row">
        <div class="container">
            <div class="header-top-left">
                <div class="header-custom-text">
                    <ul class="social-list-simple small">
                        <li>
                            <a href="#" class="icon icon-google google"></a>
                        </li>
                        <li>
                            <a href="#" class="icon icon-twitter-logo twitter"></a>
                        </li>
                        <li>
                            <a href="#" class="icon icon-facebook-logo facebook"></a>
                        </li>
                    </ul>
                </div>
                <div class="header-custom-text">
                    <span><i class="icon icon-phone"></i> +57 321 55 5555</span>
                    <span class="hidden-xs"><i class="icon icon-location"></i>
                        Acacias
                    </span>
                </div>
            </div>
            <div class="header-top-right">
                <!-- Header Links -->
                <div class="header-links">
                    <!-- Header Language -->
                    
                    <!-- /Header Language -->
                    <!-- Header Currency -->
                    
                    <!-- /Header Currency -->
                </div>
                <!-- /Header Links -->
            </div>
        </div>
    </div>
    <!-- /Header Top Row -->
    <div class="navbar">
        <div class="container">
            <!-- Menu Toggle -->
            <div class="menu-toggle"><a href="#" class="mobilemenu-toggle"><i class="icon icon-menu"></i></a></div>
            <!-- /Menu Toggle -->
            <div class="header-right-links">
                <div class="collapsed-links-wrapper">
                    <div class="collapsed-links">
                        <!-- Header Links -->
                        <div class="header-links">
                            <!-- Header WishList -->
                            <div class="header-link">
                                <a href="#"><i class="icon icon-heart"></i><span class="badge">3</span><span
                                        class="link-text">Wishlist</span></a>
                            </div>
                            <!-- Header WishList -->
                            <!-- Header Account -->
                            <?php if(auth()->guard()->check()): ?>

                                <div class="header-link dropdown-link header-account">
                                    <a href="<?php echo e(url('/home')); ?>"><i class="icon icon-home"></i><span class="link-text">Dashboard</span></a>

                                </div>
                            <?php else: ?>
                                <div class="header-link dropdown-link header-account">
                                    <a href="#"><i class="icon icon-user"></i><span class="link-text">Login</span></a>
                                    <div class="dropdown-container right">
                                        <!-- form -->
                                        <form class="theme-form" method="POST" action="<?php echo e(route('login')); ?>">
                                            <?php echo csrf_field(); ?>

                                            <h4>Sign in to account</h4>
                                            <p>Enter your email & password to login</p>

                                            <div class="form-group">
                                                <input type="hidden" name="csrf-token" value="<?php echo csrf_token(); ?>">
                                                <label class="col-form-label">Email Address</label>
                                                <input id="email" type="email"
                                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                                    value="admin@kronnos.com<?php echo e(old('email')); ?>" required
                                                    autocomplete="off" autofocus>
                                                <span>
                                                    <strong>admin@kronnos.com</strong>
                                                </span>
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-form-label">Password</label>
                                                <div class="form-input position-relative">
                                                    <input id="password" type="password" value="123456"
                                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="password" required autocomplete="current-password">
                                                    <span>
                                                        <strong>123456</strong>
                                                    </span>
                                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="form-group mb-0">

                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="remember"
                                                        id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                                    <label class="form-check-label" for="remember">
                                                        <?php echo e(__('Remember Me')); ?>

                                                    </label>
                                                </div>
                                                <?php if(Route::has('password.request')): ?>
                                                    <a class="link" href="<?php echo e(route('password.request')); ?>">
                                                        <?php echo e(__('Forgot Your Password?')); ?>

                                                    </a>
                                                <?php endif; ?>
                                                <div class="text-end mt-3">
                                                    <button type="submit" class="btn btn-primary btn-block w-100">
                                                        <?php echo e(__('Login')); ?>

                                                    </button>
                                                </div>
                                            </div>

                                            
                                        </form>
                                        <!-- /form -->
                                        <div class="title">OR</div>
                                        <div class="bottom-text">Create a <a href="/register">New
                                                Account</a></div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- /Header Account -->
                        </div>
                        <!-- /Header Links -->
                        <!-- Header Cart -->
                        <div class="header-link dropdown-link header-cart variant-1">
                            <a href="#"> <i class="icon icon-cart"></i> <span class="badge">3</span><span
                                    class="link-text">My
                                    Cart</span></a>
                            <!-- minicart wrapper -->
                            <div class="dropdown-container right">
                                <!-- minicart content -->
                                <div class="block block-minicart">
                                    <div class="minicart-content-wrapper">
                                        <div class="block-title">
                                            <span>Recently added item(s)</span>
                                        </div>
                                        <a class="btn-minicart-close" title="Close">&#10060;</a>
                                        <div class="block-content">
                                            <div class="minicart-items-wrapper overflowed">
                                                <ol class="minicart-items">
                                                    <li class="item product product-item">
                                                        <div class="product">
                                                            <a class="product-item-photo" href="#"
                                                                title="Long sleeve overall">
                                                                <span class="product-image-container">
                                                                    <span class="product-image-wrapper">
                                                                        <img class="product-image-photo"
                                                                            src="<?php echo e(asset('seiko')); ?>/images/products/product-16-c1.jpg"
                                                                            alt="Long sleeve overall">
                                                                    </span>
                                                                </span>
                                                            </a>
                                                            <div class="product-item-details">
                                                                <div class="product-item-name">
                                                                    <a href="#">Long sleeve overall</a>
                                                                </div>
                                                                <div class="product-item-qty">
                                                                    <label class="label">Qty</label>
                                                                    <input class="item-qty cart-item-qty" maxlength="12"
                                                                        value="1">
                                                                    <button class="update-cart-item"
                                                                        style="display: none" title="Update">
                                                                        <span>Update</span>
                                                                    </button>
                                                                </div>
                                                                <div class="product-item-pricing">
                                                                    <div class="price-container">
                                                                        <span class="price-wrapper">
                                                                            <span class="price-excluding-tax">
                                                                                <span class="minicart-price">
                                                                                    <span
                                                                                        class="price">$139.00</span>
                                                                                </span>
                                                                            </span>
                                                                        </span>
                                                                    </div>
                                                                    <div class="product actions">
                                                                        <div class="secondary">
                                                                            <a href="#" class="action delete"
                                                                                title="Remove item">
                                                                                <span>Delete</span>
                                                                            </a>
                                                                        </div>
                                                                        <div class="primary">
                                                                            <a class="action edit" href="#"
                                                                                title="Edit item">
                                                                                <span>Edit</span>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="item product product-item">
                                                        <div class="product">
                                                            <a class="product-item-photo" href="#"
                                                                title="Lace back mini dress">
                                                                <span class="product-image-container">
                                                                    <span class="product-image-wrapper">
                                                                        <img class="product-image-photo"
                                                                            src="<?php echo e(asset('seiko')); ?>/images/products/product-20.jpg"
                                                                            alt="Lace back mini dress">
                                                                    </span>
                                                                </span>
                                                            </a>
                                                            <div class="product-item-details">
                                                                <div class="product-item-name">
                                                                    <a href="#">Lace back mini dress</a>
                                                                </div>
                                                                <div class="product-item-qty">
                                                                    <label class="label">Qty</label>
                                                                    <input class="item-qty cart-item-qty" maxlength="12"
                                                                        value="1">
                                                                    <button class="update-cart-item"
                                                                        style="display: none" title="Update">
                                                                        <span>Update</span>
                                                                    </button>
                                                                </div>
                                                                <div class="product-item-pricing">
                                                                    <div class="price-container">
                                                                        <span class="price-wrapper">
                                                                            <span class="price-excluding-tax">
                                                                                <span class="minicart-price">
                                                                                    <span
                                                                                        class="price">$79.00</span>
                                                                                </span>
                                                                            </span>
                                                                        </span>
                                                                    </div>
                                                                    <div class="product actions">
                                                                        <div class="secondary">
                                                                            <a href="#" class="action delete"
                                                                                title="Remove item">
                                                                                <span>Delete</span>
                                                                            </a>
                                                                        </div>
                                                                        <div class="primary">
                                                                            <a class="action edit" href="#"
                                                                                title="Edit item">
                                                                                <span>Edit</span>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="item product product-item">
                                                        <div class="product">
                                                            <a class="product-item-photo" href="#"
                                                                title="Backless mini dress">
                                                                <span class="product-image-container">
                                                                    <span class="product-image-wrapper">
                                                                        <img class="product-image-photo"
                                                                            src="<?php echo e(asset('seiko')); ?>/images/products/product-7.jpg"
                                                                            alt="Backless mini dress">
                                                                    </span>
                                                                </span>
                                                            </a>
                                                            <div class="product-item-details">
                                                                <div class="product-item-name">
                                                                    <a href="#">Backless mini dress</a>
                                                                </div>
                                                                <div class="product-item-qty">
                                                                    <label class="label">Qty</label>
                                                                    <input class="item-qty cart-item-qty"
                                                                        maxlength="12" value="1">
                                                                    <button class="update-cart-item"
                                                                        style="display: none" title="Update">
                                                                        <span>Update</span>
                                                                    </button>
                                                                </div>
                                                                <div class="product-item-pricing">
                                                                    <div class="price-container">
                                                                        <span class="price-wrapper">
                                                                            <span class="price-excluding-tax">
                                                                                <span class="minicart-price">
                                                                                    <span
                                                                                        class="price">$369.00</span>
                                                                                </span>
                                                                            </span>
                                                                        </span>
                                                                    </div>
                                                                    <div class="product actions">
                                                                        <div class="secondary">
                                                                            <a href="#" class="action delete"
                                                                                title="Remove item">
                                                                                <span>Delete</span>
                                                                            </a>
                                                                        </div>
                                                                        <div class="primary">
                                                                            <a class="action edit" href="#"
                                                                                title="Edit item">
                                                                                <span>Edit</span>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ol>
                                            </div>
                                            <div class="subtotal">
                                                <span class="label">
                                                    <span>Subtotal</span>
                                                </span>
                                                <div class="amount price-container">
                                                    <span class="price-wrapper"><span
                                                            class="price">$587.00</span></span>
                                                </div>
                                            </div>
                                            <div class="actions">
                                                <div class="secondary">
                                                    <a href="#" class="btn btn-alt">
                                                        <i class="icon icon-cart"></i><span>View and edit
                                                            cart</span>
                                                    </a>
                                                </div>
                                                <div class="primary">
                                                    <a class="btn" href="#">
                                                        <i class="icon icon-external-link"></i><span>Go to
                                                            Checkout</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /minicart content -->
                            </div>
                            <!-- /minicart wrapper -->
                        </div>
                        <!-- /Header Cart -->
                    </div>
                </div>
                <!-- Header Search -->
                <div class="header-link header-search header-search">
                    <div class="exp-search">
                        <form>
                            <input class="exp-search-input " placeholder="Search here ..." type="text" value="">
                            <input class="exp-search-submit" type="submit" value="">
                            <span class="exp-icon-search"><i class="icon icon-magnify"></i></span>
                            <span class="exp-search-close"><i class="icon icon-close"></i></span>
                        </form>
                    </div>
                </div>
                <!-- /Header Search -->
            </div>
            <!-- Logo -->
            <div class="header-logo">
                <a href="index.html" title="Logo"><img src="../assets/images/logo/login.png" alt="Logo" /></a>
            </div>
            <!-- /Logo -->
            <!-- Mobile Menu -->
            <div class="mobilemenu dblclick">
                <div class="mobilemenu-header">
                    <div class="title">MENU</div>
                    <a href="#" class="mobilemenu-toggle"></a>
                </div>
                <div class="mobilemenu-content">
                    <ul class="nav">
                        <li><a href="<?php echo e(route('ecommerce')); ?>">HOME</a><span class="arrow"></span>
                            
                        </li>
                        <li>
                            <a href="#" title="">Pages</a><span class="arrow"></span>
                            <ul>
                                <li>
                                    <a href="category.html" title="">Listing<span class="menu-label-alt">NEW
                                            FEATURES</span></a><span class="arrow"></span>
                                    <ul>
                                        <li><a href="category.html" title="">Classic Listing</a>
                                        </li>
                                        <li><a href="category-fixed-sidebar.html" title="">Listing Fixed
                                                Filter<span class="menu-label-alt">NEW </span></a>
                                        </li>
                                        <li><a href="category-no-filter.html" title="">Listing No Filter</a>
                                        </li>
                                        <li><a href="category-empty.html" title="">Empty Category</a></li>
                                        <li><a href="category.html" title="">Products per row</a><span
                                                class="arrow"></span>
                                            <ul>
                                                <li> <a href="category-2-per-row.html" title="">2 per
                                                        row</a></li>
                                                <li> <a href="category-3-per-row.html" title="">3 per
                                                        row</a></li>
                                                <li> <a href="category-4-per-row.html" title="">4 per
                                                        row</a></li>
                                                <li> <a href="category-5-per-row.html" title="">5 per
                                                        row</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="product.html" title="">Product</a><span class="arrow"></span>
                                    <ul>
                                        <li> <a href="product.html" title="">Classic design</a><span
                                                class="arrow"></span>
                                            <ul>
                                                <li> <a href="product-image-small.html" title="">Image
                                                        small</a></li>
                                                <li> <a href="product-image-medium.html" title="">Image
                                                        medium</a></li>
                                                <li> <a href="product-image-medium-plus.html" title="">Image
                                                        medium plus</a></li>
                                                <li> <a href="product-image-large.html" title="">Image
                                                        large</a></li>
                                            </ul>
                                        </li>
                                        <li> <a href="product-creative.html" title="">Creative design</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="index.html" title="">Headers</a><span class="arrow"></span>
                                    <ul>
                                        <li> <a href="header-variant-1.html" title="">Header 1 (one row
                                                shift)</a> </li>
                                        <li> <a href="header-variant-2.html" title="">Header 2 (one row)</a>
                                        </li>
                                        <li> <a href="header-variant-3.html" title="">Header 3 (one row
                                                dark)</a> </li>
                                        <li> <a href="header-variant-4.html" title="">Header 4 (three
                                                rows)</a> </li>
                                        <li> <a href="header-variant-5.html" title="">Header 5 (two
                                                rows)</a> </li>
                                        <li> <a href="header-variant-6.html" title="">Header 6 (two rows
                                                center)</a> </li>
                                        <li> <a href="header-variant-7.html" title="">Header 7 (three
                                                row)</a> </li>
                                        <li> <a href="header-variant-8.html" title="">Header 8
                                                (department)</a> </li>
                                        <li> <a href="header-variant-9.html" title="">Header 9
                                                (creative)</a> </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="index.html" title="">Footers</a><span class="arrow"></span>
                                    <ul>
                                        <li> <a href="footer-variant-1.html" title="">Footer 1 (simple)</a>
                                        </li>
                                        <li> <a href="footer-variant-2.html" title="">Footer 2 (links)</a>
                                        </li>
                                        <li> <a href="footer-variant-3.html" title="">Footer 3 (menu)</a>
                                        </li>
                                        <li> <a href="footer-variant-4.html" title="">Footer 4
                                                (advanced)</a> </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="gallery.html" title="">Gallery</a><span class="arrow"></span>
                                    <ul>
                                        <li> <a href="gallery.html" title="">Gallery 2 in row</a> </li>
                                        <li> <a href="gallery-3-per-row.html" title="">Gallery 3 in row</a>
                                        </li>
                                        <li> <a href="gallery-simple.html" title="">No isotope Gallery</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="blog.html" title="">Blog</a>
                                    <ul>
                                        <li> <a href="blog.html" title="">List+Sidebar</a> </li>
                                        <li> <a href="blog-grid-2.html" title="">Grid 2</a> </li>
                                        <li> <a href="blog-grid-3.html" title="">Grid 3</a> </li>
                                        <li> <a href="blog-grid-4.html" title="">Grid 4</a> </li>
                                        <li> <a href="blog-single.html" title="">Single Post</a> </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" title="">Pages</a><span class="arrow"></span>
                                    <ul>
                                        <li> <a href="faq.html" title="">Faq</a> </li>
                                        <li> <a href="about.html" title="">About Us</a> </li>
                                        <li> <a href="contact.html" title="">Contact Us</a> </li>
                                        <li> <a href="404.html" title="">404</a> </li>
                                        <li> <a href="typography.html" title="">Typography</a> </li>
                                        <li> <a href="coming-soon.html" title="">Coming soon</a> </li>
                                        <li> <a href="login.html" title="">Login</a> </li>
                                        <li> <a href="account-create.html" title="">Account</a> </li>
                                        <li> <a href="cart.html" title="">Cart</a> </li>
                                        <li> <a href="cart-empty.html" title="">Empty Cart</a> </li>
                                        <li> <a href="wishlist.html" title="">Wishlist</a> </li>
                                    </ul>
                                </li>
                                <li> <a href="http://seiko-shopify.big-skins.com/banners-grid-online-editor/"
                                        title="">Banners / Grid Editor<span class="menu-label-alt">EXCLUSIVE</span></a>
                                </li>
                            </ul>
                        </li>
                        <li><a href="category.html">Men</a></li>
                        <li><a href="category.html">Women</a></li>
                        <li><a href="category.html">Electronics</a></li>
                    </ul>
                </div>
            </div>
            <!-- Mobile Menu -->
            <!-- Mega Menu -->
            <div class="megamenu fadein blackout">
                <ul class="nav">
                    <li class="simple-dropdown">
                        <a href="<?php echo e(route('ecommerce')); ?>">HOME</a>
                        
                    </li>
                    
                    <li><a href="category.html">Sale</a></li>
                </ul>
            </div>
            <!-- /Mega Menu -->
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\Kronnos_V2\resources\views/layouts/seiko/header.blade.php ENDPATH**/ ?>