<footer class="footer footer-fix">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 footer-copyright text-center">
                <p class="mb-0">Copyright <?php echo e(date('Y')); ?> © Kronnos</p>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\Kronnos_V2\resources\views/layouts/cuba/footer.blade.php ENDPATH**/ ?>